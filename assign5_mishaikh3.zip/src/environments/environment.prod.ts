export const environment = {
  production: true,
  clientID: "7d28e68e4b314715a83a964eb0215792",
  clientSecret:"a4a72f72a2be4b44ad30e6812083c830"
};
