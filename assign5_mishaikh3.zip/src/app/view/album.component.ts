import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { MusicDataService } from '../music-data.service';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html'
})
export class AlbumComponent implements OnInit {
  album : any;
  constructor(private route: ActivatedRoute, private snackBar : MatSnackBar, private data: MusicDataService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params=>{
      let ID = params['id'];
      this.data.getAlbumById(ID).subscribe(data =>{
        this.album = data;
        console.log(this.album);
      })
    });
  }
  addToFavourites(trackID: string): boolean{
    let success = this.data.addToFavourites(trackID);
    if(success === true){
      this.snackBar.open("Adding to Favourites...", "Done", { duration: 1500 });
      return true;
    }
    else{
      this.snackBar.open("There was an error","Error",{duration:1500} )
      return false;
    }
  }
}
